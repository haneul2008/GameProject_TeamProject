#include "Scene.h"

void Scene::Update()
{
}

void Scene::Render()
{
}