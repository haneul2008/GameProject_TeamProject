#pragma once
class DataSaver
{
public:
	const int GetBestScore() const;
	void SetBestScore(const int& score);
};

