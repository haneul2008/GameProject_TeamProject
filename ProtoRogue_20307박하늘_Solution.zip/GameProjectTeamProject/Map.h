#pragma once
class Map
{
};

