#pragma once
const int MAP_WIDTH = 70;
const int MAP_HEIGHT = 30;
const int MAX_ROOM = 8;
const int MAX_ROOM_WIDTH = 12;
const int MAX_ROOM_HEIGHT = 7;
const int MIN_ROOM_WIDTH = 7;
const int MIN_ROOM_HEIGHT = 5;
const int ROOM_MINDISTANCE = 15;
const int MIN_ENEMY = 5;
const int MAX_ENEMY = 8;
const int MIN_ITEM = 5;
const int MAX_ITEM = 8;
