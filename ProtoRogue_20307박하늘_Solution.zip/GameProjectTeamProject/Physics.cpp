#include "Physics.h"

#include <algorithm>

PhysicsManager::PhysicsManager() {
}

PhysicsManager::~PhysicsManager() {
}

void PhysicsManager::setMaxMoveBound(int x, int y) {
    _maxHeight = y;
    _maxWidth = x;
}

Collider* PhysicsManager::getCollider(const Pos& pos) const {
    for (Collider* collider : _colliders) {
        if (*collider->getPosition() == pos)
            return collider;
    }
    return nullptr;
}

Collider* PhysicsManager::getCollider(const Collider& owner, int x, int y) const {
    return this->getCollider(owner, { x, y });
}

Collider* PhysicsManager::getCollider(const Collider& owner, const Pos& pos) const {
    for (Collider* collider : _colliders) {
        if (*collider->getPosition() == pos && &owner != collider)
            return collider;
    }
    return nullptr;
}

void PhysicsManager::addCollider(Collider* collider) {
    _colliders.push_back(collider);
}

void PhysicsManager::removeCollider(Collider* collider) {
    if (collider != nullptr)
        // remove : ã�� ��Ҹ� �� ��ġ�� �̵���Ű�� �� ��ġ ��ȯ
        _colliders.erase(std::remove(_colliders.begin(), _colliders.end(), collider), _colliders.end());
}

Collider* PhysicsManager::getCollider(const Collider& owner) const {
    for (Collider* collider : _colliders) {
        if (&owner != collider && collider->calculateCollision(owner))
            return collider;
    }
    return nullptr;
}

int PhysicsManager::getMaxHeight() {
    return _maxHeight;
}

int PhysicsManager::getMaxWidth() {
    return _maxWidth;
}

Collider::Collider() :
    _isTrigger(false),
    _layer(0),
    _pPosition(nullptr) {
}

Collider::~Collider() {
}

void Collider::init(pPos pPos, bool trigger, int layer) {
    _pPosition = pPos;
    _isTrigger = trigger;
    _layer = layer;
}

void Collider::active() {
    PhysicsManager::GetInstance()->addCollider(this);
}

void Collider::deActive() {
    PhysicsManager::GetInstance()->removeCollider(this);
}

int Collider::getCollidedObjectLayer(const Collider& other) {
    bool collision = calculateCollision(other);
    return collision ? isOverlapLayer(other.getLayer()) : 0;
}

bool Collider::isAnyTrigger(const Collider& other) const {
    return this->_isTrigger || other.getIsTrigger();
}

bool Collider::isOverlapLayer(int layer) const {
    return (this->_layer & layer) != 0;
}

bool Collider::getIsTrigger() const {
    return _isTrigger;
}

int Collider::getLayer() const {
    return _layer;
}

void Collider::setLayer(int layer) {
    _layer = layer;
}

pPos Collider::getPosition() const {
    return _pPosition;
}

void Collider::setOriginPosition(pPos position) {
    _pPosition = position;
}

bool Collider::tryCollision(const Pos& previousPos) {
    const PhysicsManager* physicsManager = PhysicsManager::GetInstance();

    Collider* collider = physicsManager->getCollider(*this);
    if (collider != nullptr) {
        bool triggerCollsition = isAnyTrigger(*collider);
        if (triggerCollsition)
            onTriggerEvent(*collider, previousPos);
        else
            onCollisionEvent(*collider, previousPos);

        return true;
    }

    return false;
}

