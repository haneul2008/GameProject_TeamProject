#pragma once
class Transition
{
public:
	Transition();
};

