#pragma once
#include<random>

class Random
{
public:
	int GetRandomPoint(int start, int end);
};

